<?php if(!defined('INCLUDE_PATH')){die('error!');};?><style>
.footer{
	border-top:1px solid #ccc;
	width:1000px;
	margin:auto;
	line-height:30px;
	font-size:14px;
	text-align:center;
	padding-top:5px;
	margin-top:10px;
}
.footer a{
	margin:0px 8px;
}
.copyright{
	font-size:12px;
	line-height:25px;
}
</style>
<div class="clear" style="clear:both"></div>
<style>
#to_top{width:30px; height:40px; padding:20px; font:14px/20px arial; text-align:center;  background:#06c; position:fixed; cursor:pointer; color:#fff;right:0px;bottom:0px;}
</style>
<script>
window.onload = function(){
  var oTop = document.getElementById("to_top");
 
  oTop.onclick = function(){
    document.documentElement.scrollTop = document.body.scrollTop =0;
  }
}  

</script>
<div id="to_top">返回顶部</div>
</body>
</html>
</html>