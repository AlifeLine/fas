<?php
echo '<!DOCTYPE html>
<html lang="cn" class="bg-dark">
<head>
<meta charset="utf-8" />
<title>FAS3.0ϵͳ��Ŀ¼</title>'
?>
